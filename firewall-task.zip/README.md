# Firewall Configuration and Testing

## 📌 Objective
Configure and test basic firewall rules to allow or block network traffic on Windows/Linux as part of the internship task.

---

## 🛠 Tools Used
- **Operating System:** Windows 10 / Ubuntu 20.04 (choose your OS here)
- **Firewall Tool:**
  - Windows: Windows Defender Firewall with Advanced Security
  - Linux: UFW (Uncomplicated Firewall)

---

## 📋 Steps Performed

### 1. **Checked Existing Firewall Rules**
- **Windows:** Opened `Windows Defender Firewall with Advanced Security` → Checked `Inbound Rules` and `Outbound Rules`.
- **Linux:** Ran:
```bash
sudo ufw status verbose
```
![Screenshot: Existing Rules](screenshots/existing_rules.png)

---

### 2. **Blocked Port 23 (Telnet)**
- **Windows:** Created a new inbound rule for TCP port 23 → Chose "Block the connection" → Saved the rule.
- **Linux:** Ran:
```bash
sudo ufw deny 23/tcp
```
![Screenshot: Block Port 23](screenshots/block_port_23.png)

---

### 3. **Tested the Rule**
- Tried to connect to port 23 using:
```bash
telnet <IP> 23
```
- Connection was blocked as expected.
![Screenshot: Telnet Block Test](screenshots/telnet_block_test.png)

---

### 4. **Allowed SSH (Linux only)**
```bash
sudo ufw allow 22/tcp
```
![Screenshot: Allow SSH](screenshots/allow_ssh.png)

---

### 5. **Removed the Test Rule**
- **Windows:** Deleted the inbound block rule for port 23.
- **Linux:**
```bash
sudo ufw delete deny 23/tcp
```
![Screenshot: Remove Rule](screenshots/remove_rule.png)

---

## 📊 Summary of Results
- Successfully blocked and tested port 23.
- Verified that SSH was allowed (Linux only).
- Restored firewall to original state after testing.

---

## 📚 Key Learning
- How to check existing firewall rules.
- How to block/allow ports using Windows Firewall and UFW.
- Understanding inbound and outbound rules.
- The importance of port management for security.

---

## 📂 Repository Contents
```
firewall-task/
│
├── README.md                  # This file
├── screenshots/               # All task screenshots
│   ├── existing_rules.png
│   ├── block_port_23.png
│   ├── telnet_block_test.png
│   ├── allow_ssh.png
│   └── remove_rule.png
```

---

## 📝 Interview Questions
1. What is a firewall?
2. Difference between stateful and stateless firewall?
3. What are inbound and outbound rules?
4. How does UFW simplify firewall management?
5. Why block port 23 (Telnet)?
6. What are common firewall mistakes?
7. How does a firewall improve network security?
8. What is NAT in firewalls?

---
